import { Injectable } from '@angular/core';
import axios from 'axios';
import { ApiConfigService } from './api-config.service';

export interface Usuario {
  id?: number;
  nombre: string;
  email: string;
  password?: string;
  creado_en?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}

@Injectable({
  providedIn: 'root',
})
export class UsuariosService {

  constructor(private apiConfig: ApiConfigService) {}

  // La URL se arma en cada llamada con la IP que se escribió en el login
  private get API_URL(): string {
    return this.apiConfig.url('Usuarios.php');
  }

  obtenerUsuarios(): Promise<ApiResponse<Usuario[]>> {
    return axios
      .get<ApiResponse<Usuario[]>>(this.API_URL, { timeout: this.apiConfig.timeoutMs })
      .then((res) => res.data)
      .catch((err) => this.manejarError(err, []));
  }

  obtenerUsuario(id: number): Promise<ApiResponse<Usuario | null>> {
    return axios
      .get<ApiResponse<Usuario>>(this.API_URL, { params: { id }, timeout: this.apiConfig.timeoutMs })
      .then((res) => res.data)
      .catch((err) => this.manejarError(err, null));
  }

  crearUsuario(usuario: Usuario): Promise<ApiResponse<{ id: number } | null>> {
    return axios
      .post<ApiResponse<{ id: number }>>(this.API_URL, usuario, {
        headers: { 'Content-Type': 'application/json' },
        timeout: this.apiConfig.timeoutMs,
      })
      .then((res) => res.data)
      .catch((err) => this.manejarError(err, null));
  }

  actualizarUsuario(id: number, usuario: Usuario): Promise<ApiResponse<null>> {
    return axios
      .put<ApiResponse<null>>(this.API_URL, usuario, {
        params: { id },
        headers: { 'Content-Type': 'application/json' },
        timeout: this.apiConfig.timeoutMs,
      })
      .then((res) => res.data)
      .catch((err) => this.manejarError(err, null));
  }

  eliminarUsuario(id: number): Promise<ApiResponse<null>> {
    return axios
      .delete<ApiResponse<null>>(this.API_URL, { params: { id }, timeout: this.apiConfig.timeoutMs })
      .then((res) => res.data)
      .catch((err) => this.manejarError(err, null));
  }

  // Si el servidor respondió con un error (400, 404, 409, etc.) axios lo trae en err.response
  private manejarError<T>(err: any, dataPorDefecto: T): ApiResponse<T> {
    if (err.response && err.response.data) {
      return err.response.data as ApiResponse<T>;
    }
    return {
      success: false,
      message: 'No se pudo conectar con el servidor',
      data: dataPorDefecto,
    };
  }
}