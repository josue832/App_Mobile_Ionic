import { Component } from '@angular/core';
import { IonContent, IonSearchbar, IonIcon } from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  notificationsOutline,
  starOutline,
  timeOutline,
  leafOutline,
  fishOutline,
  fastFoodOutline,
  appsOutline,
} from 'ionicons/icons';

interface Categoria {
  nombre: string;
  icono: string;
}

interface Receta {
  nombre: string;
  tiempo: string;
  dificultad: 'Fácil' | 'Media' | 'Difícil';
  kcal: number;
}

@Component({
  selector: 'app-recetas',
  templateUrl: './recetas.page.html',
  styleUrls: ['./recetas.page.scss'],
  imports: [IonContent, IonSearchbar, IonIcon],
})
export class RecetasPage {

  categorias: Categoria[] = [
    { nombre: 'Todas', icono: 'appsOutline' },
    { nombre: 'Vegano', icono: 'leafOutline' },
    { nombre: 'Proteína', icono: 'fishOutline' },
    { nombre: 'Snacks', icono: 'fastFoodOutline' },
  ];

  categoriaActiva = 'Todas';

  // Datos de ejemplo — se conectarán a la API más adelante
  recetas: Receta[] = [
    { nombre: 'Bowl de Quinoa y Vegetales', tiempo: '45 min', dificultad: 'Fácil', kcal: 750 },
    { nombre: 'Ensalada de Pollo y Aguacate', tiempo: '20 min', dificultad: 'Fácil', kcal: 480 },
  ];

  constructor() {
    addIcons({
      notificationsOutline,
      starOutline,
      timeOutline,
      leafOutline,
      fishOutline,
      fastFoodOutline,
      appsOutline,
    });
  }

  elegirCategoria(nombre: string) {
    this.categoriaActiva = nombre;
  }
}
