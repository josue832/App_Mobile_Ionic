import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IonContent, IonIcon } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { arrowBackOutline, timeOutline, flameOutline, listOutline } from 'ionicons/icons';
import { RecetasService, RecetaDetalle } from '../services/recetas.service';

@Component({
  selector: 'app-receta-detalle',
  templateUrl: './receta.detalle.page.html',
  styleUrls: ['./receta.detalle.page.scss'],
  imports: [IonContent, IonIcon],
})
export class RecetaDetallePage implements OnInit {

  receta: RecetaDetalle | null = null;
  cargando = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private recetasService: RecetasService
  ) {
    // Se registran con clave en kebab-case (así los busca ion-icon internamente);
    // si se registran con el nombre de la variable en camelCase, ion-icon no
    // encuentra coincidencia local y trata de descargarlo de internet, lo que
    // provoca los warnings "Could not load icon..." y hace lenta la carga.
    addIcons({
      'arrow-back-outline': arrowBackOutline,
      'time-outline': timeOutline,
      'flame-outline': flameOutline,
      'list-outline': listOutline,
    });
  }

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (id) {
      this.cargarReceta(id);
    }
  }

  async cargarReceta(id: number) {
    this.cargando = true;
    const res = await this.recetasService.obtenerReceta(id);
    this.cargando = false;

    if (res.success) {
      this.receta = res.data;
    }
  }

  regresar() {
    this.router.navigate(['/tabs/recetas']);
  }
}